@echo off
:: =============================================================
::  AMBIENT NOTES - First-Time Setup Script
::  Model: Qwen3-ASR 1.7B by Alibaba / Qwen
::  Run ONCE in PowerShell or CMD (preferably as Administrator)
:: =============================================================

echo.
echo ============================================================
echo   AMBIENT NOTES SETUP  -  Qwen3-ASR 1.7B
echo ============================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found.
    echo         Download from: https://www.python.org/downloads/
    echo         Check "Add Python to PATH" during install.
    pause & exit /b 1
)
echo [OK] Python found:
python --version
echo.

echo [1/6] Creating virtual environment...
python -m venv canary_env
call canary_env\Scripts\activate.bat
python -m pip install --upgrade pip --quiet
echo       Done.
echo.

echo [2/6] Installing PyTorch (CPU)...
pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu --quiet
echo       Done.
echo.

echo [3/6] Installing Qwen3-ASR package...
pip install qwen-asr --quiet
echo       Done.
echo.

echo [4/6] Installing audio tools...
pip install pyaudio --prefer-binary --quiet
if %errorlevel% neq 0 (
    echo [WARN] Direct install failed. Trying binary wheel...
    pip install pyaudio --only-binary :all: --quiet
)
pip install soundfile numpy huggingface_hub --quiet
echo       Done.
echo.

echo [5/6] Installing ffmpeg...
winget install --id Gyan.FFmpeg -e --silent
echo       Done.
echo.

echo [6/6] Verifying installation...
python -c "import torch; print('  torch    :', torch.__version__)"
python -c "from qwen_asr import Qwen3ASRModel; print('  qwen-asr : OK')"
python -c "import pyaudio; print('  pyaudio  : OK')"
echo.

echo ============================================================
echo   SETUP COMPLETE!
echo ============================================================
echo.
echo   To run the app:
echo     1. .\canary_env\Scripts\activate
echo     2. python ambient_notes.py
echo.
echo   Or just double-click run.bat
echo.
echo   NOTE: First launch downloads the model (~3.5 GB).
echo         This only happens once.
echo ============================================================
echo.
pause
