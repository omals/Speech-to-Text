# 🎙️ Ambient Notes — AI Speech-to-Text Note Taking App

> Speak naturally. Your words are saved automatically.  
> Powered by **Qwen3-ASR 1.7B** — open-source, offline, runs entirely on your machine.

---

## 📌 Overview

**Ambient Notes** is a lightweight command-line speech-to-text application that continuously listens to your microphone, transcribes your speech using the **Qwen3-ASR 1.7B** model by Alibaba/Qwen, and saves timestamped notes to a plain text file — no internet required after the first model download.

```
🎙️  Speak  →  🧠  Qwen3-ASR 1.7B (local)  →  📝  notes.txt
```

---

## ✨ Features

- 🔴 **Ambient recording** — records in continuous 10-second chunks automatically
- 🧠 **Local AI inference** — Qwen3-ASR 1.7B runs fully offline on CPU
- 🌍 **52 languages supported** — auto-detects language, no configuration needed
- 📝 **Timestamped notes** — every transcription saved with date and time
- 💻 **Windows CMD/PowerShell compatible** — no Linux required
- 🔒 **100% private** — no data sent to any server

---

## 🤖 Model: Qwen3-ASR 1.7B

| Property | Details |
|---|---|
| **Model** | Qwen3-ASR 1.7B |
| **Developer** | Alibaba / Qwen Team |
| **Parameters** | 1.7 Billion |
| **Languages** | 52 languages |
| **Performance** | Competitive with top commercial APIs |
| **Backend** | Hugging Face Transformers |
| **Model Size** | ~3.5 GB download |
| **HuggingFace** | [Qwen/Qwen3-ASR-1.7B](https://huggingface.co/Qwen/Qwen3-ASR-1.7B) |

---

## 🖥️ System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| **OS** | Windows 10/11 | Windows 11 |
| **Python** | 3.10+ | 3.12 |
| **RAM** | 12 GB | 16 GB |
| **Disk Space** | 6 GB free | 10 GB free |
| **GPU** | Not required | NVIDIA GPU (optional, faster) |
| **Microphone** | Any input device | USB or built-in mic |

> ✅ Tested on: Intel i3-1115G4 @ 3.00GHz · 16 GB RAM · Intel UHD Graphics · Windows 11

---

## 📁 Project Structure

```
ambient-notes/
│
├── ambient_notes.py       # Main app — record, transcribe, save
├── setup.bat              # One-time Windows setup script
├── run.bat                # Quick launch script
├── notes.txt              # Output file (auto-created on first run)
└── README.md              # This file
```

---

## ⚙️ Installation

### Step 1 — Clone the repository

```bash
git clone https://github.com/yourusername/ambient-notes.git
cd ambient-notes
```

### Step 2 — Run the setup script (Windows)

Right-click `setup.bat` → **Run as Administrator**, or in PowerShell:

```powershell
.\setup.bat
```

This will automatically:
- ✅ Create a Python virtual environment (`canary_env/`)
- ✅ Install PyTorch (CPU build)
- ✅ Install `qwen-asr` package
- ✅ Install PyAudio and audio dependencies
- ✅ Install ffmpeg (via winget)

> ⏱️ First-time setup takes **15–25 minutes** depending on your internet speed.

### Step 3 — Manual install (if setup.bat fails)

```powershell
# Create and activate virtual environment
python -m venv canary_env
.\canary_env\Scripts\activate

# Install PyTorch CPU
pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu

# Install Qwen ASR package
pip install qwen-asr

# Install audio tools
pip install pyaudio soundfile numpy huggingface_hub

# Install ffmpeg (run as Administrator)
winget install --id Gyan.FFmpeg -e
```

---

## ▶️ Usage

### Quick Start

Double-click `run.bat` or in PowerShell:

```powershell
.\canary_env\Scripts\activate
python ambient_notes.py
```

### What you'll see

```
============================================================
   AMBIENT NOTES  |  Qwen3-ASR 1.7B  |  CPU Mode
============================================================

[1/3] Loading Qwen3-ASR 1.7B model...
      Model loaded successfully!

[2/3] Notes will be saved to: C:\Users\you\ambient-notes\notes.txt
[3/3] Starting ambient recording loop.
      Speak naturally. Press Ctrl+C to stop.

------------------------------------------------------------

[CHUNK #1]
[MIC]  Using device: Microphone (Realtek Audio)
[REC]  Recording 10s ..... Done.
[STT]  Transcribing...
[TEXT] Meeting with the client is scheduled for Friday at 3 PM.
[TIME] Transcribed in 18.4s
[SAVE] Appended to notes.txt
------------------------------------------------------------
```

### Stop recording

Press `Ctrl + C` at any time. A session summary is shown:

```
[STOP] Recording stopped by user.
       Session duration : 0:05:32
       Chunks recorded  : 33
       Notes saved to   : C:\Users\you\ambient-notes\notes.txt
```

---

## 📄 Output Format

All transcriptions are saved to `notes.txt` with timestamps:

```
[2026-06-15 10:32:45]
Meeting with client discussed Q3 budget and delivery timeline.

[2026-06-15 10:33:10]
Action item — send the revised proposal by Friday afternoon.

[2026-06-15 10:45:02]
Research note — look into Qwen3-ASR forced aligner for timestamps.
```

---

## ⚙️ Configuration

Edit these variables at the top of `ambient_notes.py`:

```python
CHUNK_SECONDS = 10          # How many seconds to record per chunk
SAMPLE_RATE   = 16000       # Audio sample rate (16kHz required)
CHANNELS      = 1           # Mono audio
NOTES_FILE    = "notes.txt" # Output filename
```

---

## 🐢 CPU Performance Guide

Running on CPU (no NVIDIA GPU) is fully supported. Expected speeds:

| Chunk Length | Approx. Transcription Time |
|---|---|
| 10 seconds | 15 – 40 seconds |
| 30 seconds | 45 – 90 seconds |
| Real-time streaming | ❌ Not feasible on CPU |

> 💡 **Tip:** 10-second chunks offer the best balance of responsiveness and accuracy on CPU systems.

---

## 🌍 Supported Languages (52 total)

Qwen3-ASR 1.7B auto-detects language. Includes:

`English` · `Chinese` · `Hindi` · `Spanish` · `French` · `Arabic` · `Bengali` · `Russian` · `Portuguese` · `Urdu` · `Japanese` · `Korean` · `German` · `Italian` · `Turkish` · `Tamil` · `Telugu` · `Malayalam` · `Kannada` · `Marathi` · and 32 more.

---

## 🔧 Troubleshooting

### PyAudio installation fails on Windows
```powershell
# Try direct install without pipwin
pip install pyaudio --prefer-binary

# Or download pre-built wheel manually from:
# https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
pip install PyAudio‑0.2.14‑cp312‑cp312‑win_amd64.whl
```

### ffmpeg warning appears
```powershell
# Install via winget
winget install --id Gyan.FFmpeg -e

# Then add to PATH (System Properties → Environment Variables → Path → New):
# C:\Users\<you>\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_...\ffmpeg-8.x.x-full_build\bin
```

### OSError: Paging file too small
Increase Windows virtual memory:  
`System Properties → Advanced → Performance Settings → Advanced → Virtual Memory → Change`  
Set Initial: `20480 MB` · Maximum: `40960 MB` → Restart PC

### Model download is slow
```powershell
# Install faster HuggingFace downloader
pip install huggingface_hub[hf_xet] hf_xet
```

### NeMo / transformers version conflict
```powershell
pip install --upgrade transformers>=4.51.0
```

---

## 🔄 Switching Models

To use a smaller/faster model (0.6B):

```python
# In ambient_notes.py, change the model name:
model = Qwen3ASRModel.from_pretrained("Qwen/Qwen3-ASR-0.6B", ...)
```

| Model | Size | Speed (CPU) | Accuracy |
|---|---|---|---|
| Qwen3-ASR-0.6B | ~1.2 GB | Fast | Good |
| **Qwen3-ASR-1.7B** | ~3.5 GB | Medium | **Best** ✅ |

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `qwen-asr` | Qwen3-ASR model loader and inference |
| `torch` | PyTorch CPU inference engine |
| `torchaudio` | Audio processing |
| `pyaudio` | Microphone input capture |
| `soundfile` | WAV file read/write |
| `numpy` | Audio array processing |
| `huggingface_hub` | Model download from HuggingFace |
| `ffmpeg` | Audio format conversion |

---

## 🛣️ Roadmap

- [ ] GUI window with live transcript display (Tkinter)
- [ ] Export notes to `.docx` / `.pdf`
- [ ] Keyword search across saved notes
- [ ] Configurable chunk length via command-line argument
- [ ] Voice activity detection (skip silent chunks)
- [ ] Timestamp per sentence using Qwen3-ForcedAligner-0.6B

---

## 📜 License

This project is released under the **MIT License**.  
The Qwen3-ASR model is released under the **Apache 2.0 License** by Alibaba Cloud.

---

## 🙏 Acknowledgements

- [Qwen Team @ Alibaba Cloud](https://github.com/QwenLM/Qwen3-ASR) for the Qwen3-ASR model series
- [Hugging Face](https://huggingface.co/Qwen/Qwen3-ASR-1.7B) for model hosting
- [Gyan.dev](https://www.gyan.dev/ffmpeg/builds/) for Windows ffmpeg builds

---

<p align="center">
  Made with ❤️ for offline, private, ambient note-taking
</p>
